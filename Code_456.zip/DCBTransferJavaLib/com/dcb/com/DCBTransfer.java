package com.dcb.com;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class DCBTransfer {
	public static Properties property = null;
	public static final String filePath = "/var/mqsi/flowpropfiles/DCBTransfer/";
	public static String fileName = "dcbtransfer.properties";

	public static void setFileName(String fname) {
		fileName = fname;
	}

	public static String getProperty(String strProperty) {
		if (property == null) {
			property = new Properties();
			try {
				InputStream is = new FileInputStream(filePath + fileName);
				property.load(is);

			} catch (IOException iExcep) {
				return iExcep.getMessage();
			}
		}
		return property.getProperty(strProperty);
	}
}